
param (
    [string]$resourceGroupName,
    [string]$storageAccountName,
    [string]$location
)


# Create the storage account
New-AzStorageAccount -ResourceGroupName $resourceGroupName -Name $storageAccountName -Location $location -SkuName Standard_LRS