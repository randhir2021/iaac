
param (
    [string]$resourceGroupName,
    [string]$action
)

$vmList = Get-AzVM -ResourceGroupName $resourceGroupName

foreach ($vm in $vmList) {
    if ($action -eq "Start") {
        Start-AzVM -ResourceGroupName $resourceGroupName -Name $vm.Name
    } elseif ($action -eq "Stop") {
        Stop-AzVM -ResourceGroupName $resourceGroupName -Name $vm.Name -Force
    }
}