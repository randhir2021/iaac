param (
    [string]$resourceGroupName,
    [string]$virtualNetworkName1,
    [string]$virtualNetworkName2
)


# Get the virtual networks
$vnet1 = Get-AzVirtualNetwork -ResourceGroupName $resourceGroupName -Name $virtualNetworkName1
$vnet2 = Get-AzVirtualNetwork -ResourceGroupName $resourceGroupName -Name $virtualNetworkName2

# Create the peering
Add-AzVirtualNetworkPeering -Name "Peering-$virtualNetworkName1-$virtualNetworkName2" -VirtualNetwork $vnet1 -RemoteVirtualNetworkId $vnet2.Id
