param (
    [string]$folderPath,
    [int]$daysToKeep
)

$limit = (Get-Date).AddDays(-$daysToKeep)
Get-ChildItem -Path $folderPath -Recurse | Where-Object { $_.LastWriteTime -lt $limit } | Remove-Item -Force