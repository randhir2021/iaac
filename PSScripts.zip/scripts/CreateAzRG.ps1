
param (
    [string]$resourceGroupName,
    [string]$location
)

# Create the resource group
New-AzResourceGroup -Name $resourceGroupName -Location $location